export interface IReactChatbotProps {
    description: string;
    ctx: any;
}
//# sourceMappingURL=IReactChatbotProps.d.ts.map