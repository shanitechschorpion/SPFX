import * as React from 'react';
import { IReactChatbotProps } from './IReactChatbotProps';
export default class ReactChatbot extends React.Component<IReactChatbotProps, {}> {
    render(): React.ReactElement<IReactChatbotProps>;
}
//# sourceMappingURL=ReactChatbot.d.ts.map