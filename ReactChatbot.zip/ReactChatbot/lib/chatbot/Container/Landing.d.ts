export declare const Landing: (props: any) => JSX.Element;
//# sourceMappingURL=Landing.d.ts.map