export declare const ChatBotClose: (props: any) => JSX.Element;
//# sourceMappingURL=ChatBotClose.d.ts.map