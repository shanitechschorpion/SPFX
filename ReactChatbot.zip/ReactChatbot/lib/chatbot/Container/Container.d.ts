import './Container.css';
export declare const Container: (props: any) => JSX.Element;
//# sourceMappingURL=Container.d.ts.map