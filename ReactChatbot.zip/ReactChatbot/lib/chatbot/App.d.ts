import * as React from 'react';
import { IAppProps, IAppState } from './IApp';
import 'jquery';
import 'bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
export default class App extends React.Component<IAppProps, IAppState> {
    constructor(props: IAppProps);
    protected chatbotToggle(): void;
    protected landingScreenToggle(currentResponse: any): void;
    protected getChatBotResponses(): void;
    render(): React.ReactElement<IAppProps>;
}
//# sourceMappingURL=App.d.ts.map