import { IAppState } from "./IApp";
export declare let initialState: IAppState;
//# sourceMappingURL=initialState.d.ts.map