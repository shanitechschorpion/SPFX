import './FloaterButton.css';
export declare const FloaterButton: (props: any) => JSX.Element;
//# sourceMappingURL=FloaterButton.d.ts.map