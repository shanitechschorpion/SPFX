export declare const FloaterIcon: (props: any) => JSX.Element;
//# sourceMappingURL=FloaterIcon.d.ts.map