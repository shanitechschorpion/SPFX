declare const styles: {};
export default styles;
//# sourceMappingURL=Chat.scss.d.ts.map