import * as React from 'react';
export interface IChatProps {
}
export interface IChatState {
    messages: any;
    responses: any;
}
export default class Chat extends React.Component<IChatProps, IChatState> {
    constructor(props: any);
    componentDidMount(): void;
    demo(): void;
    addMessage(item: any): void;
    handleSubmit(e: any): void;
    mockReply(): void;
    render(): JSX.Element;
}
//# sourceMappingURL=ChatBotApp.d.ts.map