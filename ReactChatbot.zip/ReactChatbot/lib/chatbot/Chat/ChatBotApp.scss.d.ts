declare const styles: {};
export default styles;
//# sourceMappingURL=ChatBotApp.scss.d.ts.map