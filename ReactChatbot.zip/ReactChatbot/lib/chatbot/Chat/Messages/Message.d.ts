import * as React from 'react';
export interface IMessageProps {
    message: any;
    index: any;
    handleSubmitButton: Function;
}
export interface IMessageState {
    delayDots: boolean;
}
export declare const OptionButton: (props: any) => JSX.Element;
export declare const OptionsButton: (props: any) => JSX.Element;
export declare const OptionsLink: (props: any) => JSX.Element;
export default class Message extends React.Component<IMessageProps, IMessageState> {
    constructor(props: IMessageProps);
    render(): JSX.Element;
}
//# sourceMappingURL=Message.d.ts.map