export declare const scrollTop: (timeout: any) => void;
//# sourceMappingURL=scrollTop.d.ts.map