import * as React from 'react';
import './Chat.scss';
export interface IChatProps {
    responses: any;
    currentResponse: any;
    userDetail: any;
    chatbotToggle: Function;
    ctx: any;
}
export interface IChatState {
    messages: any;
    responses: any;
    selectedQuestion: any;
    askExpert: any;
}
export default class Chat extends React.Component<IChatProps, IChatState> {
    constructor(props: any);
    componentDidMount(): void;
    addMessage(item: any): void;
    protected handleSubmitInput(e: any): void;
    protected handleSubmitButton(action: any, body: any): void;
    protected botResponse(searchText: any): void;
    protected askAnExpert(): void;
    render(): JSX.Element;
}
//# sourceMappingURL=Chat.d.ts.map