export interface IAppState {
    responses: any;
    userDetail: userProfile;
    isOpen: boolean;
    isLanding: boolean;
    currentResponse: any;
}
export interface userProfile {
    name: any;
    email: any;
    id: any;
}
export interface IAppProps {
    ctx?: any;
}
//# sourceMappingURL=IApp.d.ts.map