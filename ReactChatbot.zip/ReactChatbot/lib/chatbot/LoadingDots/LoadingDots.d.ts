import './LoadingDots.css';
export declare const LoadingDots: () => JSX.Element;
//# sourceMappingURL=LoadingDots.d.ts.map