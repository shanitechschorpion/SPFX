export declare const ModalWrapper: (props: any) => JSX.Element;
//# sourceMappingURL=ModalWrapper.d.ts.map