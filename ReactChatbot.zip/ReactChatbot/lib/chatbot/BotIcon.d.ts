export declare const BotIcon: (props: any) => JSX.Element;
//# sourceMappingURL=BotIcon.d.ts.map