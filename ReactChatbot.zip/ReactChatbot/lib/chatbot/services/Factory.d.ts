export default class Factory {
}
//# sourceMappingURL=Factory.d.ts.map