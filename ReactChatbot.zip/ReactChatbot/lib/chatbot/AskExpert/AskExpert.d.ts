import * as React from 'react';
import './AskExpert.css';
export interface IAskExpertProps {
    askExpert: Function;
}
export default class AskExpert extends React.Component<IAskExpertProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=AskExpert.d.ts.map