export default class Factory {
    private ctx;
    constructor(ctx: any);
    getListItems(metadata: {
        listName: string;
        select?: any;
        filter?: any;
        expand?: any;
        orderBy?: any;
        top?: number;
    }): Promise<any>;
    getLoggedInUser(): Promise<any>;
    private formQuery;
    private formSelector;
}
//# sourceMappingURL=Factory.d.ts.map