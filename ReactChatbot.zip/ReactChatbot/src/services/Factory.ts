import axios from 'axios';
import  {IDigestCache, DigestCache} from '@microsoft/sp-http';

export default class Factory {
    private ctx: any;
    // Get Chatbot responses
    public constructor(ctx) {
        this.ctx = ctx;
    }

    public getListItems(metadata: {listName: string, select?: any, filter? : any, expand? : any, orderBy?: any, top?: number}): Promise<any> {
        const { listName } = metadata;
        const finalQuery = this.formQuery(metadata);
        return new Promise<any>((resolve: (Item: any) => void, reject: (error: any) => void): void => {  
            try {
                axios({
                    method: 'get',
                    url: this.ctx.pageContext.web.absoluteUrl + `/_api/web/lists/getbytitle('${listName}')/items${finalQuery}`,
                    headers: { 
                        "Accept": "application/json;odata=nometadata", 
                        "content-type": "application/json;odata=nometadata", 
                    }
                }).then(response=>{
                    resolve(response.data.value);
                });
            } 
            catch(err) {
                console.log(err.message);
                reject(err.message);
            }
        });
    }

    public getLoggedInUser(): Promise<any> {
        return new Promise<any>((resolve: (Item: any) => void, reject: (error: any) => void): void => {  
            try {
                axios({
                    method: 'get',
                    url: this.ctx.pageContext.web.absoluteUrl + `/_api/web/getuserbyid(${this.ctx.legacyPageContext["userId"]})`,
                    headers: { 
                        "Accept": "application/json;odata=nometadata", 
                        "content-type": "application/json;odata=nometadata", 
                    }
                }).then(response=>{
                    resolve(response.data.value);
                });
            } 
            catch(err) {
                console.log(err.message);
                reject(err.message);
            }
        });
    }

    private formQuery(metadata) {
        let finalQuery = "";
        const {select, filter, expand, top, orderBy} = metadata;

        let selectQuery = this.formSelector(select, "Select");
        let expandQuery = this.formSelector(expand, "expand");

        if(select && select.length>0 && expand && expand.length>0) {
            finalQuery = `?$${selectQuery}&$${expandQuery}`;
        } else if(select && select.length>0) {
            finalQuery = `?$${selectQuery}`;
        }

        if(finalQuery.indexOf('?')!==-1 && filter && filter!="") {
            finalQuery += `&$filter=${filter}`;
        } else if(filter && filter!=="") {
            finalQuery = `?$filter=${filter}`;
        }

        if(finalQuery.indexOf('?')!==-1 && orderBy) {
            finalQuery += `&$orderby=${orderBy}`;
        } else if(orderBy) {
            finalQuery = `?$orderby=${orderBy}`;
        }

        if(finalQuery.indexOf('?')!==-1 && top) {
            finalQuery += `&$top=${top}`;
        } else if(top) {
            finalQuery = `?$top=${top}`;
        }
        
        return finalQuery;
    }

    private formSelector(selector: any, type: any) {
        let selectQuery: any;
        if(selector) {
            selector.map((x, index)=>{
                if(index===0) {
                    selectQuery = `${type}=` + x;
                } else {
                    selectQuery += ',' + x;
                }
            });
        }
        return selectQuery;
    }
}