import * as React from 'react';
import styles from './ReactChatbot.module.scss';
import { IReactChatbotProps } from './IReactChatbotProps';
import { escape } from '@microsoft/sp-lodash-subset';
import App from '../../../chatbot/App';

export default class ReactChatbot extends React.Component<IReactChatbotProps, {}> {
  public render(): React.ReactElement<IReactChatbotProps> {
    return (
      <div className={ styles.reactChatbot }>
        <div className={ styles.container }>
          <App ctx={this.props.ctx}/>
        </div>
      </div>
    );
  }
}
