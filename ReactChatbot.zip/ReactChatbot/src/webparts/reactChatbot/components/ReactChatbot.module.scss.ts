/* tslint:disable */
require("./ReactChatbot.module.css");
const styles = {
  reactChatbot: 'reactChatbot_4fae7bae',
  container: 'container_4fae7bae',
  row: 'row_4fae7bae',
  column: 'column_4fae7bae',
  'ms-Grid': 'ms-Grid_4fae7bae',
  title: 'title_4fae7bae',
  subTitle: 'subTitle_4fae7bae',
  description: 'description_4fae7bae',
  button: 'button_4fae7bae',
  label: 'label_4fae7bae'
};

export default styles;
/* tslint:enable */