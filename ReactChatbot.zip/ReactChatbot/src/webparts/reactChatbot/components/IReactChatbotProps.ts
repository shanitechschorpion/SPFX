export interface IReactChatbotProps {
  description: string;
  ctx: any;
}
