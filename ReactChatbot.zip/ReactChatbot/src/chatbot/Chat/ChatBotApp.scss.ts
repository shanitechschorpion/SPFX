/* tslint:disable */
require("./ChatBotApp.css");
const styles = {

};

export default styles;
/* tslint:enable */