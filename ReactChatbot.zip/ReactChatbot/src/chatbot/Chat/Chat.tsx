import * as React from 'react';
import Message from './Messages/Message';
import './Chat.scss';
import { scrollTop } from './scrollTop';
import axios from 'axios';
import  {IDigestCache, DigestCache} from '@microsoft/sp-http';
import { ModalWrapper } from '../ModalWrapper/ModalWrapper';


export interface IChatProps {
    responses: any;
    currentResponse: any;
    userDetail: any;
    chatbotToggle:Function;
    ctx: any;
}
export interface IChatState {
    messages: any;
    responses: any;
    selectedQuestion: any;
    askExpert: any;
}

export default class Chat extends React.Component<IChatProps, IChatState> {
    public constructor(props) {
        super(props);

        this.state = {
            messages: [],
            selectedQuestion: {},
            responses: 0,
            askExpert: this.addMessage
        };

        this.handleSubmitInput = this.handleSubmitInput.bind(this);
        this.handleSubmitButton = this.handleSubmitButton.bind(this);
        this.addMessage = this.addMessage.bind(this);
        this.botResponse = this.botResponse.bind(this);

    }

    public componentDidMount() {
        const {body, text, action, options} = this.props.currentResponse;
        setTimeout(()=> this.addMessage({ body: `Hello ${this.props.userDetail.name}`, author: 'bot', userInput: true, inputType: 'text'}),100);
        this.handleSubmitButton({text, action}, body);
    }

    public addMessage(item) {
        if(item.author==="bot" && item.options) {
            item.options = Array.isArray(item.options) ? item.options : JSON.parse(item.options);
        } 

        item.created = new Date();
        this.setState({
            messages: [...this.state.messages, item]
        });
        
        scrollTop(100);
    }

    protected handleSubmitInput(e) {
        e.preventDefault();
        this.addMessage({
            author: 'human',
            body: e.target[0].value,
            inputType: "text",
            userInput: true
        });
        this.botResponse(e.target[0].value);
        e.target[0].value = "";
    }

    protected handleSubmitButton(action, body) {
        setTimeout(() => this.addMessage({ author: "bot", body: body, inputType: "text", userInput: true}),100);
        this.setState(()=>({ messages: this.state.messages.filter((x:any) => x.body!==body)}));
        
        if(action.text == "Ask an expert") {
            this.setState(()=>({ askExpert : true }));
        } else {
            this.setState(()=>({ askExpert : false }));
        }

        setTimeout(()=>{
            this.addMessage({ body: action.text, inputType: 'text', userInput: true, author: 'human'});
        }, 200);

        let nextAction = this.props.responses.find((x)=>x.searchTags.split(',').indexOf(action.action.toLowerCase())!==-1);
        if(nextAction) {
            nextAction.author = "bot";
            setTimeout(() => this.addMessage(nextAction),500);
        }
    }

    protected botResponse(searchText: any) {
        let response = this.props.responses.find((x:any)=> x.searchTags!==null && x.searchTags.toLowerCase()===searchText.toLowerCase());
        if(response) {
            response.author = 'bot';
            setTimeout(()=> this.addMessage(response),600);
        } else {
            response = this.props.responses.filter((x:any)=> x.searchTags!==null && x.searchTags.toLowerCase().includes(searchText.toLowerCase()));
            if(response.length>0) {
                response.map((x:any,index: number)=>{
                    x.author = "bot";
                    if(index<6){
                        setTimeout(() => this.addMessage(x), 600);
                    }
                });
            } else {
                setTimeout(() => this.addMessage({ author: 'bot', body: 'I didn\'t get it, can you please rephrase it?', inputType: 'Text', userInput: true }), 600);
            }
        }
    }

    protected askAnExpert() {
        let query: any = document.getElementById('askanexpert-msg') as any;

        let digestCache: IDigestCache = this.props.ctx.serviceScope.consume(DigestCache.serviceKey);
        let data = {
            __metadata : { 'type': 'AskanExpertListItem' },
            Title: this.props.userDetail.name,
            Email: this.props.userDetail.email,
            Message: query.value
        };

        const _self = this;

        // digestCache.fetchDigest(this.props.ctx.pageContext.web.serverRelativeUrl)
        // .then((digest: string)=>{
        //     axios({
        //         method: 'post',
        //         url: "siteURL",
        //         data: JSON.stringify(data),
        //         headers: { "Accept": "application/json;odata=nometadata", "content-type": "application/json;odata=nometadata", "x-RequestDigest": digest}
        //     }).then(response=>{
        //         console.log(response);
        //         _self.props.chatbotToggle();
        //     })
        // })
    }

    public render() {
        const lastItem = this.state.messages[this.state.messages.length-1];
        return (
            <React.Fragment>
                <ModalWrapper />
            <div className="chat-bot-message-box c-chat c-chat--ready">
                {/* <div id="Header">
                    <div id="HeaderTitle">
                        {/* <HeaderIcon /> 
                        <h1 className="ChatBotHeader">ChatBot</h1>
                    </div>
                </div> */}
                <ul className="c-chat__list">
                    {
                        this.state.messages.map((message, index) => {
                            return (
                                <Message 
                                    key={index} 
                                    index={index} 
                                    message={message} 
                                    handleSubmitButton={this.handleSubmitButton} />
                            );
                        })
                    }
                </ul>
                
            </div>
            <form className="c-chat__form" onSubmit={this.handleSubmitInput}>
            <input 
                type="text" 
                name="input" 
                id="userInput" 
                placeholder="Type your message here..." 
                autoFocus 
                autoComplete="off" 
                required
                disabled={lastItem && !lastItem.userInput}
            />
        </form>
        </React.Fragment>
        );
    }
}

