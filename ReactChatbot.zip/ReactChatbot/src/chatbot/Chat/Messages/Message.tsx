import * as React from 'react';
import {LoadingDots} from '../../LoadingDots/LoadingDots';
import { scrollTop} from '../scrollTop';
export interface IMessageProps {
    message: any;
    index: any;
    handleSubmitButton: Function;
}

export interface IMessageState {
    delayDots: boolean;
}

export const OptionButton = (props: any) => {
    return (
        <button className="ansButton form-control btn-sm" onClick={props.handleSubmitButton.bind(this, props.option, props.body)} >
            {props.option.text}
        </button>
    );
};

export const OptionsButton = (props: any) => {
    return (
        <React.Fragment>
            {
                props.delayDots ? <LoadingDots /> :
                    <React.Fragment>
                        { props.body && 
                            <p className="bodyMessage">
                                {/* <FloaterIcon className="chat-bot-icon"/> */}
                                <span dangerouslySetInnerHTML={{ __html: props.body }}></span>       
                            </p>
                        }
                        <div className="btn-container">
                        {
                            props.options && props.options.map((x:any) =>{
                                return (
                                    <OptionButton   option={x} body={props.body} handleSubmitButton={props.handleSubmitButton} />
                                );
                            })
                        }
                        </div>
                       
                    </React.Fragment>
            }
        </React.Fragment>
    );
};


export const OptionsLink = (props) => {
    return (
        <React.Fragment>
            {
                props.body && <p className="bodyMessage" dangerouslySetInnerHTML={{ __html: props.body }}></p>
            }

            {
                props.options && props.options.map((x: any)=>{
                    if(x.action.indexOf("https://")!==-1 || x.action.indexOf("http://")!==-1 || x.action.indexOf("rahultrimukhe777@gmail.com")!==-1) {
                        return (
                            <a href={x.action} target="_blank">
                                <button className="ansButton" >{x.title}</button>
                            </a>
                        );
                    } else {
                        return (
                            <OptionButton option={x} body={props.body}  handleSubmitButton={props.handleSubmitButton}/>
                        );
                    }
                    
                })
            }
        </React.Fragment>
    );
};

export default class Message extends React.Component<IMessageProps, IMessageState> {
    public constructor(props: IMessageProps) {
        super(props);
        this.state = {
            delayDots : true
        };
        
        const _self = this;
        setTimeout(()=>{
            _self.setState(()=>({ delayDots: false }));
        },1000);
        scrollTop(1000);
    }

    public render() {
        const {author, body, options, inputType, created } = this.props.message;
        return (
            <li className={"c-chat__item c-chat__item--" + author}>
                { 
                    body && inputType==="text" && 
                        <div className="c-chat__message" dangerouslySetInnerHTML={{ __html: body }}></div>
                }

                {
                    inputType==="button" && 
                        <OptionsButton delayDots={this.state.delayDots} body={body} options={options} handleSubmitButton={this.props.handleSubmitButton}/>
                }

                {
                    inputType==="link" && <OptionsLink delayDots={this.state.delayDots} body={body} options={options} handleSubmitButton={this.props.handleSubmitButton} />
                }

                { author === "human" && <br/> }

                <span style={{ fontSize: '9px '}}>
                    {`${created.toString().split(" ")[4]}}, Today` }
                </span>
            </li>
        );
    }
}
