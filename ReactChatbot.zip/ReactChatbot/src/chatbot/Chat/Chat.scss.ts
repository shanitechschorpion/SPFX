/* tslint:disable */
require("./Chat.css");
const styles = {

};

export default styles;
/* tslint:enable */