import * as React from 'react';

export const BotIcon = (props) => {
    return (
        <img className={props.className && props.className} src="https://cdn0.iconfinder.com/data/icons/kameleon-free-pack-rounded/110/Chat-2-512.png" />
    );
};