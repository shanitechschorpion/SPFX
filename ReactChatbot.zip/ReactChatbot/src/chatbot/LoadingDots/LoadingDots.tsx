import * as React from 'react';
import './LoadingDots.css';
import {BotIcon} from './../BotIcon';

export const LoadingDots = () => {
    return (
        <React.Fragment>
            <div className="loading-box">
                <BotIcon className="chat-bot-icon"/>
                <div className="loading">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </div>
        </React.Fragment>
    );
};