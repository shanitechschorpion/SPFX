import * as React from 'react';
import Chat from '../Chat/Chat';
import { ChatBotClose } from './ChatBotClose';

import './Container.css';

export const Container = (props: any) => {
    return (
        <React.Fragment>
            <div className="chatbot-container-box container-new">
                { 
                    !props.isLanding && 
                        <h1 className="ChatBotHeader">
                            ChatBot
                            <span onClick= {props.chatbotToggle } className="chatbot-icon-cross">X</span>
                        </h1> 
                }
                { props.children }
            </div>
        </React.Fragment>
    );
};