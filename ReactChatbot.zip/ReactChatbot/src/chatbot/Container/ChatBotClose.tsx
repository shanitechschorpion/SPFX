import * as React from 'react';

export const ChatBotClose = (props) => {
    return (
        <div className="chatbot-icon-cross" onClick={props.chatbotToggle}>
            X
        </div>
    );
};