import * as React from 'react';
// import './Landing.css';

export const Landing = (props: any) => {
    const {body, options} = props.response ? props.response : { body: 'Welcome to the default Chatbot', options: [{title: 'Go Inside', action: "goinside"}] };
    const optionList = Array.isArray(options) ? options : JSON.parse(options);
    return (
        <React.Fragment>
            <div className="chatbot-landing-container containt" style={{ background: "url(./../1.jpg)"}}>
                <p className="welcome-header">
                    {`Hello ${props.userDetail.name}`}
                </p>
                <div className="header-content" dangerouslySetInnerHTML={{ __html: body }}></div>
                <div className="containt-buttons">
                    {
                        optionList.map(x=>{
                            
                            return (
                                <button onClick={()=> props.landingScreenToggle({body, text: x.text, action: x.action, options: optionList})}>
                                    {x.text}
                                </button>
                            );
                        }) 
                    }
                </div>
            </div>
        </React.Fragment>
    );
};