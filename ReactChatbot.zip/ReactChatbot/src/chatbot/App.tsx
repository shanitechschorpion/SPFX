import * as React from 'react';
import Chat from './Chat/Chat';
import { Container } from './Container/Container';
import { Landing } from './Container/Landing';
import { FloaterButton } from './FloaterButton/FloaterButton';
import {IAppProps, IAppState} from './IApp';
import {initialState} from './initialState';
import 'jquery';
import 'bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import axios from 'axios';
import  {IDigestCache, DigestCache} from '@microsoft/sp-http';
import './App.css';
import Factory from '../services/Factory';

export default class App extends React.Component<IAppProps, IAppState>{
    // App constructor
    public constructor(props: IAppProps){
        super(props);
        this.state = {...initialState, userDetail: {
            name: this.props.ctx.pageContext._legacyPageContext["userDisplayName"],
            email: this.props.ctx.pageContext._legacyPageContext["userEmail"],
            id: this.props.ctx.pageContext._legacyPageContext["userId"]
        }};

        this.chatbotToggle = this.chatbotToggle.bind(this);
        this.landingScreenToggle = this.landingScreenToggle.bind(this);
        this.getChatBotResponses = this.getChatBotResponses.bind(this);
        this.getChatBotResponses();
        const service = new Factory(props.ctx);
        const _self = this;
        service.getListItems(
            {
                listName: 'ChatBot Database', 
                select: ['Title','Id','inputType','body','options','searchTags','userInput'], 
                top: 2
                // expand: ['Author/Id']
                // filter: 'Id eq 2'
            }).then((response)=>{
                _self.setState(()=>({ responses : response }));
                console.log(response);
            }
        );

        
    }

    // Toggle chatbot/floater (open/close) button
    protected chatbotToggle() {
        if(this.state.isOpen) {
            this.setState(()=>({ isOpen: false }));
        } else {
            this.setState(()=>({ isOpen: true, isLanding: true }));
        }
    }

    // Toggle landing screen and send the response to the chatbot screen
    protected landingScreenToggle(currentResponse: any) {
        this.setState(()=>({ isLanding: !this.state.isLanding, currentResponse }));
    }

    // Get Chatbot responses
    protected getChatBotResponses() {
        const _self = this;
        try {
            axios({
                method: 'get',
                url: this.props.ctx.pageContext.web.absoluteUrl + `/_api/web/lists/getbytitle('ChatBot Database')/items`,
                headers: { 
                    "Accept": "application/json;odata=nometadata", 
                    "content-type": "application/json;odata=nometadata", 
                }
            }).then(response=>{
                // _self.setState(()=>({ responses : response.data.value }));
                console.log(_self.state.responses);
            });
        } 
        catch(err) {
            console.log(err.message);
        }
    }

    // Render App component with conditional chatbot/open chatbot button
    public render(): React.ReactElement<IAppProps> {
        const {
            responses,
            userDetail,
            isOpen,
            isLanding,
            currentResponse
        } = this.state;

        return(
            <React.Fragment>
                {
                    isOpen ?
                        <Container chatbotToggle={this.chatbotToggle} isLanding={isLanding} responses={responses}>
                                {
                                    isLanding 
                                        ?  <Landing 
                                                chatbotToggle={this.chatbotToggle} 
                                                userDetail={this.state.userDetail} 
                                                landingScreenToggle={this.landingScreenToggle} 
                                                isLanding={isLanding}
                                                response={this.state.responses.find((x)=>x.searchTags.toLowerCase()==="start")}
                                            /> 
                                        : <Chat 
                                            ctx={this.props.ctx} 
                                            responses={this.state.responses} 
                                            currentResponse={currentResponse} 
                                            userDetail={userDetail} 
                                            chatbotToggle={this.chatbotToggle}
                                        />
                                }
                        </Container>
                        
                    : <FloaterButton chatbotToggle={this.chatbotToggle}/>
                }
            </React.Fragment>
        );
    }
}
