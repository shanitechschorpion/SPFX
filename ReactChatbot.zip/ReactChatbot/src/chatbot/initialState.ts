import { IAppState } from "./IApp";

export let initialState: IAppState = {
    responses: [
        {
            body: 'Welcome to the Bot service',
            userInput: true,
            inputType: 'text',
            options: "",
            searchTags: "goinside"
        }
    ],
    userDetail: {
        name: 'Annonyms',
        id: '',
        email: ''
    },
    isOpen: false,
    isLanding: true,
    currentResponse: {}
};