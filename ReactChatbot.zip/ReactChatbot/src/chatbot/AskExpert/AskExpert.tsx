import * as React from 'react';
import './AskExpert.css';

export interface IAskExpertProps  {
    askExpert: Function;
}

export default class AskExpert extends React.Component<IAskExpertProps> {
    public render(){
        return (
            <form id="askanexpertform">
                <div className="form-group">
                    <label>
                        Our Experts will respond you to your queries.
                    </label>
                    <textarea className="form-control" id="askanexpert-msg" rows={5} placeholder="Type your query here..."></textarea>
                    <button type="button" className="btn" onClick={this.props.askExpert.bind(this)}>
                        Submit
                    </button>
                </div>
            </form>
        );
    }
}