import * as React from 'react';
import { BotIcon } from '../BotIcon';
import './FloaterButton.css';


export const FloaterButton =(props: any) => {
    return (
        <div className="FloaterBox" onClick={props.chatbotToggle}>
            <a className="chatbot-icon">
                <BotIcon/>
            </a>
        </div>
    );
};